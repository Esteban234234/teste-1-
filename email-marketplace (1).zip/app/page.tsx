import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, Mail, Users, Filter, Star } from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Mail className="h-8 w-8 text-blue-600" />
            <span className="text-2xl font-bold text-gray-900">EmailPro</span>
          </div>
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="#features" className="text-gray-600 hover:text-gray-900">
              Fonctionnalités
            </Link>
            <Link href="#pricing" className="text-gray-600 hover:text-gray-900">
              Tarifs
            </Link>
            <Link href="/login" className="text-gray-600 hover:text-gray-900">
              Connexion
            </Link>
            <Button asChild>
              <Link href="/register">Commencer</Link>
            </Button>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center">
          <Badge className="mb-4" variant="secondary">
            Plus de 50,000 emails d'entreprises
          </Badge>
          <h1 className="text-5xl font-bold text-gray-900 mb-6">
            Accédez aux meilleures listes d'emails d'entreprises
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Développez votre business avec nos listes d'emails qualifiées et à jour. Filtrez par secteur, taille
            d'entreprise et localisation.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" asChild>
              <Link href="/register">Commencer maintenant</Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="#demo">Voir la démo</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-20 px-4 bg-white">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Pourquoi choisir EmailPro ?</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card>
              <CardHeader>
                <Users className="h-12 w-12 text-blue-600 mb-4" />
                <CardTitle>Base de données massive</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Plus de 50,000 emails d'entreprises vérifiés et mis à jour régulièrement.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <Filter className="h-12 w-12 text-blue-600 mb-4" />
                <CardTitle>Filtrage avancé</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Filtrez par secteur d'activité, taille d'entreprise, localisation et plus encore.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CheckCircle className="h-12 w-12 text-blue-600 mb-4" />
                <CardTitle>Qualité garantie</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">Emails vérifiés avec un taux de délivrabilité supérieur à 95%.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-20 px-4">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Choisissez votre plan</h2>
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <Card>
              <CardHeader>
                <CardTitle>Starter</CardTitle>
                <CardDescription>Parfait pour débuter</CardDescription>
                <div className="text-3xl font-bold">
                  29€<span className="text-sm font-normal">/mois</span>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-sm">5,000 emails</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Filtrage basique</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Export CSV</span>
                  </div>
                </div>
                <Button className="w-full bg-transparent" variant="outline">
                  Choisir ce plan
                </Button>
              </CardContent>
            </Card>

            <Card className="border-blue-600 relative">
              <Badge className="absolute -top-2 left-1/2 transform -translate-x-1/2" variant="default">
                <Star className="h-3 w-3 mr-1" />
                Populaire
              </Badge>
              <CardHeader>
                <CardTitle>Pro</CardTitle>
                <CardDescription>Pour les professionnels</CardDescription>
                <div className="text-3xl font-bold">
                  79€<span className="text-sm font-normal">/mois</span>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-sm">25,000 emails</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Filtrage avancé</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Export CSV/Excel</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Support prioritaire</span>
                  </div>
                </div>
                <Button className="w-full">Choisir ce plan</Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Enterprise</CardTitle>
                <CardDescription>Pour les grandes entreprises</CardDescription>
                <div className="text-3xl font-bold">
                  199€<span className="text-sm font-normal">/mois</span>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Emails illimités</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Tous les filtres</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-sm">API Access</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Support dédié</span>
                  </div>
                </div>
                <Button className="w-full bg-transparent" variant="outline">
                  Nous contacter
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 px-4">
        <div className="container mx-auto text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Mail className="h-6 w-6" />
            <span className="text-xl font-bold">EmailPro</span>
          </div>
          <p className="text-gray-400 mb-4">La solution professionnelle pour vos campagnes email</p>
          <div className="flex justify-center space-x-6 text-sm">
            <Link href="/privacy" className="hover:text-gray-300">
              Confidentialité
            </Link>
            <Link href="/terms" className="hover:text-gray-300">
              Conditions
            </Link>
            <Link href="/contact" className="hover:text-gray-300">
              Contact
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
