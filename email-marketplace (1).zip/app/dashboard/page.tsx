"use client"

import { useState, useEffect, useMemo } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Mail, Search, Download, Filter, LogOut, Building, MapPin, Users } from "lucide-react"

// Données mockées des emails d'entreprises
const emailDatabase = [
  {
    id: 1,
    company: "TechCorp Solutions",
    email: "contact@techcorp.fr",
    sector: "Technologie",
    size: "Grande entreprise",
    location: "Paris",
    employees: 500,
    verified: true,
  },
  {
    id: 2,
    company: "Marketing Plus",
    email: "info@marketingplus.fr",
    sector: "Marketing",
    size: "PME",
    location: "Lyon",
    employees: 50,
    verified: true,
  },
  {
    id: 3,
    company: "Green Energy Co",
    email: "hello@greenenergy.fr",
    sector: "Énergie",
    size: "Startup",
    location: "Marseille",
    employees: 15,
    verified: true,
  },
  {
    id: 4,
    company: "Finance Pro",
    email: "contact@financepro.fr",
    sector: "Finance",
    size: "Grande entreprise",
    location: "Paris",
    employees: 200,
    verified: true,
  },
  {
    id: 5,
    company: "Health Solutions",
    email: "info@healthsolutions.fr",
    sector: "Santé",
    size: "PME",
    location: "Toulouse",
    employees: 80,
    verified: true,
  },
  {
    id: 6,
    company: "Retail Express",
    email: "contact@retailexpress.fr",
    sector: "Commerce",
    size: "PME",
    location: "Bordeaux",
    employees: 120,
    verified: true,
  },
  {
    id: 7,
    company: "EduTech France",
    email: "hello@edutech.fr",
    sector: "Éducation",
    size: "Startup",
    location: "Nice",
    employees: 25,
    verified: true,
  },
  {
    id: 8,
    company: "Construction Leader",
    email: "info@constructionleader.fr",
    sector: "Construction",
    size: "Grande entreprise",
    location: "Lille",
    employees: 300,
    verified: true,
  },
]

export default function DashboardPage() {
  const [user, setUser] = useState<any>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [sectorFilter, setSectorFilter] = useState("all")
  const [sizeFilter, setSizeFilter] = useState("all")
  const [locationFilter, setLocationFilter] = useState("all")
  const [selectedEmails, setSelectedEmails] = useState<number[]>([])
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (!userData) {
      router.push("/login")
      return
    }

    const parsedUser = JSON.parse(userData)
    if (!parsedUser.subscriptionActive) {
      router.push("/pricing")
      return
    }

    setUser(parsedUser)
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem("user")
    router.push("/")
  }

  const filteredEmails = useMemo(() => {
    return emailDatabase.filter((email) => {
      const matchesSearch =
        email.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
        email.email.toLowerCase().includes(searchTerm.toLowerCase())
      const matchesSector = sectorFilter === "all" || email.sector === sectorFilter
      const matchesSize = sizeFilter === "all" || email.size === sizeFilter
      const matchesLocation = locationFilter === "all" || email.location === locationFilter

      return matchesSearch && matchesSector && matchesSize && matchesLocation
    })
  }, [searchTerm, sectorFilter, sizeFilter, locationFilter])

  const handleSelectEmail = (emailId: number) => {
    setSelectedEmails((prev) => (prev.includes(emailId) ? prev.filter((id) => id !== emailId) : [...prev, emailId]))
  }

  const handleSelectAll = () => {
    if (selectedEmails.length === filteredEmails.length) {
      setSelectedEmails([])
    } else {
      setSelectedEmails(filteredEmails.map((email) => email.id))
    }
  }

  const handleExport = () => {
    const selectedData = emailDatabase.filter((email) => selectedEmails.includes(email.id))
    const csvContent = [
      ["Entreprise", "Email", "Secteur", "Taille", "Localisation", "Employés"].join(","),
      ...selectedData.map((email) =>
        [email.company, email.email, email.sector, email.size, email.location, email.employees].join(","),
      ),
    ].join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "emails_export.csv"
    a.click()
    window.URL.revokeObjectURL(url)
  }

  if (!user) {
    return <div>Chargement...</div>
  }

  const sectors = [...new Set(emailDatabase.map((email) => email.sector))]
  const sizes = [...new Set(emailDatabase.map((email) => email.size))]
  const locations = [...new Set(emailDatabase.map((email) => email.location))]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Mail className="h-8 w-8 text-blue-600" />
            <span className="text-2xl font-bold text-gray-900">EmailPro</span>
          </div>
          <div className="flex items-center space-x-4">
            <Badge variant="secondary" className="capitalize">
              Plan {user.subscription}
            </Badge>
            <span className="text-sm text-gray-600">Bonjour, {user.firstName || user.email}</span>
            <Button variant="outline" size="sm" onClick={handleLogout}>
              <LogOut className="h-4 w-4 mr-2" />
              Déconnexion
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Stats */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <Mail className="h-8 w-8 text-blue-600" />
                <div>
                  <p className="text-2xl font-bold">{emailDatabase.length}</p>
                  <p className="text-sm text-gray-600">Emails disponibles</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <Building className="h-8 w-8 text-green-600" />
                <div>
                  <p className="text-2xl font-bold">{sectors.length}</p>
                  <p className="text-sm text-gray-600">Secteurs</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <MapPin className="h-8 w-8 text-purple-600" />
                <div>
                  <p className="text-2xl font-bold">{locations.length}</p>
                  <p className="text-sm text-gray-600">Villes</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <Users className="h-8 w-8 text-orange-600" />
                <div>
                  <p className="text-2xl font-bold">{selectedEmails.length}</p>
                  <p className="text-sm text-gray-600">Sélectionnés</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Filter className="h-5 w-5" />
              <span>Filtres et recherche</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-4 mb-4">
              <div className="space-y-2">
                <Label htmlFor="search">Recherche</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="search"
                    placeholder="Entreprise ou email..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Secteur</Label>
                <Select value={sectorFilter} onValueChange={setSectorFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Tous les secteurs" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tous les secteurs</SelectItem>
                    {sectors.map((sector) => (
                      <SelectItem key={sector} value={sector}>
                        {sector}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Taille</Label>
                <Select value={sizeFilter} onValueChange={setSizeFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Toutes les tailles" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Toutes les tailles</SelectItem>
                    {sizes.map((size) => (
                      <SelectItem key={size} value={size}>
                        {size}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Localisation</Label>
                <Select value={locationFilter} onValueChange={setLocationFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Toutes les villes" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Toutes les villes</SelectItem>
                    {locations.map((location) => (
                      <SelectItem key={location} value={location}>
                        {location}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <p className="text-sm text-gray-600">{filteredEmails.length} résultat(s) trouvé(s)</p>
              <div className="flex space-x-2">
                <Button variant="outline" onClick={handleSelectAll}>
                  {selectedEmails.length === filteredEmails.length ? "Tout désélectionner" : "Tout sélectionner"}
                </Button>
                <Button onClick={handleExport} disabled={selectedEmails.length === 0}>
                  <Download className="h-4 w-4 mr-2" />
                  Exporter ({selectedEmails.length})
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Email List */}
        <Card>
          <CardHeader>
            <CardTitle>Liste des emails</CardTitle>
            <CardDescription>Sélectionnez les emails que vous souhaitez exporter</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {filteredEmails.map((email, index) => (
                <div key={email.id}>
                  <div
                    className={`p-4 rounded-lg border cursor-pointer transition-colors ${
                      selectedEmails.includes(email.id) ? "bg-blue-50 border-blue-200" : "hover:bg-gray-50"
                    }`}
                    onClick={() => handleSelectEmail(email.id)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3">
                          <input
                            type="checkbox"
                            checked={selectedEmails.includes(email.id)}
                            onChange={() => handleSelectEmail(email.id)}
                            className="rounded"
                          />
                          <div>
                            <h3 className="font-semibold text-gray-900">{email.company}</h3>
                            <p className="text-blue-600">{email.email}</p>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4 text-sm text-gray-600">
                        <Badge variant="outline">{email.sector}</Badge>
                        <span className="flex items-center space-x-1">
                          <Building className="h-4 w-4" />
                          <span>{email.size}</span>
                        </span>
                        <span className="flex items-center space-x-1">
                          <MapPin className="h-4 w-4" />
                          <span>{email.location}</span>
                        </span>
                        <span className="flex items-center space-x-1">
                          <Users className="h-4 w-4" />
                          <span>{email.employees} emp.</span>
                        </span>
                      </div>
                    </div>
                  </div>
                  {index < filteredEmails.length - 1 && <Separator className="my-2" />}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
